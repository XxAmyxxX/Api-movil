import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput, Button } from 'react-native';
import axios from 'axios';
import { Alert } from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome'; // Importa íconos de FontAwesome
import { useNavigation } from '@react-navigation/native'; // Importa el hook de navegación

const API_URL = 'http://10.175.81.242:9300'; // Cambia 'tu_ip_o_dominio' por la IP o dominio de tu servidor Node.js

const ProductList = () => {
  const [productos, setProductos] = useState([]);
  const navigation = useNavigation(); // Obtiene el objeto de navegación

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const response = await axios.get(`${API_URL}/productos`);
      setProductos(response.data);
    } catch (error) {
      console.error('Error al recuperar datos:', error);
    }
  };

  const handleEdit = (producto) => {
    navigation.navigate('EditarProducto', { producto });
  };

  const handleDelete = async (id) => {
    // Lógica para eliminar el producto con el ID proporcionado
    try {
      Alert.alert(
        'Eliminar Producto',
        '¿Estás seguro de que deseas eliminar este producto?',
        [
          {
            text: 'Cancelar',
            style: 'cancel',
          },
          {
            text: 'Eliminar',
            onPress: async () => {
              await axios.delete(`${API_URL}/productos/${id}`);
              console.log(`Producto con ID ${id} eliminado`);
              fetchData(); // Actualizar la lista de productos después de eliminar
            },
            style: 'destructive',
          },
        ],
        { cancelable: false }
      );
    } catch (error) {
      console.error('Error al eliminar el producto:', error);
    }
  };

  const handleAdd = async () => {
    // Navegar a la pantalla de agregar producto
    await navigation.push('AgregarProducto');
    // Actualizar la lista de productos después de agregar uno nuevo
    await fetchData();
  };

  useEffect(() => {
    const unsubscribe = navigation.addListener('focus', () => {
      fetchData();
    });

    return unsubscribe;
  }, [navigation]);

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>Lista de Productos</Text>
      <TouchableOpacity onPress={handleAdd}>
        <Icon name="plus" size={30} color="#000" style={styles.addIcon} />
      </TouchableOpacity>
      {productos.map(producto => (
        <View key={producto.id_producto} style={styles.productoContainer}>
          <View style={styles.producto}>
            <View style={styles.detalleProducto}>
              <Text style={styles.nombre}>{producto.nombre_producto}</Text>
              <Text style={styles.precio}>Precio: {producto.precio}</Text>
              <Text style={styles.precio}>Categoría: {producto.categorias}</Text>
              <Text style={styles.precio}>Proveedor: {producto.proveedores}</Text>
              <Text style={styles.precio}>Stock: {producto.Cantidad_productos}</Text>
            </View>
            <View style={styles.iconContainer}>
              <TouchableOpacity onPress={() => handleEdit(producto)}>
                <Icon name="pencil" size={20} color="#0000ff" style={styles.icon} />
              </TouchableOpacity>
              <TouchableOpacity onPress={() => handleDelete(producto.id_producto)}>
                <Icon name="trash" size={20} color="#FF0000" style={styles.icon} />
              </TouchableOpacity>
            </View>
          </View>
        </View>
      ))}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    paddingHorizontal: 20,
    paddingVertical: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  productoContainer: {
    backgroundColor: '#eee',
    borderRadius: 10,
    marginBottom: 10,
    padding: 10,
    width: '100%',
    borderColor: '#000', 
    borderWidth: 1, 
  },
  producto: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  detalleProducto: {
    flex: 1,
  },
  nombre: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  precio: {
    fontSize: 16,
  },
  iconContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  icon: {
    marginHorizontal: 5,
  },
  addIcon: {
    alignSelf: 'flex-end',
    marginBottom: 20,
    color:"#228b22"
  },
});

export default ProductList;
