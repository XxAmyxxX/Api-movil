import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, Button, StyleSheet } from 'react-native';
import axios from 'axios';
import { Picker } from '@react-native-picker/picker'; 

const API_URL = 'http://10.175.81.242:9300'; // Cambia 'tu_ip_o_dominio' por la IP o dominio de tu servidor Node.js

const AgregarProducto = ({ navigation }) => {
  const [nuevoProducto, setNuevoProducto] = useState({
    nombre_producto: '',
    precio: '',
    id_Categoria: '',
    id_proveedor: '',
    Cantidad_productos: ''
    // Agrega más campos según sea necesario
    
  });
  const [categorias, setCategorias] = useState([]);
  const [proveedores, setProveedores] = useState([]);

  useEffect(() => {
    fetchCategorias();
    fetchProveedores();
  }, []);

  const fetchCategorias = async () => {
    try {
      const response = await axios.get(`${API_URL}/categorias`);
      // La respuesta debe ser un array de objetos { id_Categoria, Categorias }
      setCategorias(response.data);
    } catch (error) {
      console.error('Error al obtener categorías:', error);
    }
  };
  
  const fetchProveedores = async () => {
    try {
      const response = await axios.get(`${API_URL}/proveedores`);
      // La respuesta debe ser un array de objetos { id_proveedor, proveedores }
      setProveedores(response.data);
    } catch (error) {
      console.error('Error al obtener proveedores:', error);
    }
  };
  

  const handleChange = (campo, valor) => {
    setNuevoProducto({
      ...nuevoProducto,
      [campo]: valor
    });
  };

  const handleAgregarProducto = async () => {
    try {
      // Realiza la solicitud para agregar el producto
      const response = await axios.post(`${API_URL}/productos`, nuevoProducto);
      // Maneja la respuesta aquí si es necesario
      console.log('Producto agregado:', response.data);

      // Navega de regreso a la pantalla de lista de productos
      navigation.goBack();
    } catch (error) {
      console.error('Error al agregar producto:', error);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Agregar Producto</Text>
      <Text style={styles.label}>Nombre Producto</Text>
      <TextInput
        style={styles.input}
        placeholder="Nombre del producto"
        value={nuevoProducto.nombre_producto}
        onChangeText={(text) => handleChange('nombre_producto', text)}
      />
        <Text style={styles.label}>Precio</Text>
      <TextInput
        style={styles.input}
        placeholder="Precio"
        value={nuevoProducto.precio}
        onChangeText={(text) => handleChange('precio', text.replace(/[^0-9]/g, ''))}
        keyboardType="numeric" // Teclado numérico
      />
      <Text style={styles.label} >Categorias</Text>
            <Picker
        style={styles.input}
        selectedValue={nuevoProducto.id_Categoria}
        onValueChange={(itemValue) => handleChange('id_Categoria', itemValue)}
        >
        <Picker.Item label="Seleccionar categoría" value="" />
        {categorias.map(categoria => (
            <Picker.Item key={categoria.id_Categoria} label={categoria.Categorias} value={categoria.id_Categoria} />
        ))}
        </Picker>
        <Text style={styles.label}>Proveedor</Text>
        <Picker
        style={styles.input}
        selectedValue={nuevoProducto.id_proveedor}
        onValueChange={(itemValue) => handleChange('id_proveedor', itemValue)}
        >
        <Picker.Item label="Seleccionar proveedor" value="" />
        {proveedores.map(proveedor => (
            <Picker.Item key={proveedor.id_proveedor} label={proveedor.proveedores} value={proveedor.id_proveedor} />
        ))}
        </Picker>
        <Text style={styles.label}>Cantidad</Text>
      <TextInput
        style={styles.input}
        placeholder="Cantidad de productos"
        value={nuevoProducto.Cantidad_productos}
        onChangeText={(text) => handleChange('Cantidad_productos', text.replace(/[^0-9]/g, ''))}
        keyboardType="numeric" // Teclado numérico
      />
      {/* Agrega más campos de entrada según sea necesario */}
      <Button title="Agregar Producto" onPress={handleAgregarProducto} />
    </View>
  );
};

const styles = StyleSheet.create({
    container: {
      flex: 1,
      alignItems: 'center',
      justifyContent: 'center',
      paddingHorizontal: 20,
      backgroundColor: '#6495ed',
    },
    title: {
      fontSize: 24,
      fontWeight: 'bold',
      marginBottom: 20,
      color: '#000000', 
      textAlign: 'left', 
    },
    input: {
      width: '100%',
      height: 40,
      backgroundColor: '#ffffff', 
      borderColor: '#000000', 
      borderWidth: 1,
      marginBottom: 10,
      paddingHorizontal: 10,
      borderRadius: 5,
      textAlign: 'left',
    },
    label: {
      fontSize: 16,
      marginBottom: 5,
      textAlign: 'left'
    }
});

export default AgregarProducto;