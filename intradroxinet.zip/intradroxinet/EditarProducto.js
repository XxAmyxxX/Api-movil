import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, Button, StyleSheet } from 'react-native';
import axios from 'axios';
import { Alert } from 'react-native';
import { Picker } from '@react-native-picker/picker';

const API_URL = 'http://10.175.81.242:9300';

const EditarProducto = ({ route, navigation }) => {
  const { producto } = route.params;
  const [productoEditado, setProductoEditado] = useState({
    nombre_producto: producto.nombre_producto ? producto.nombre_producto : '',
    precio: producto.precio ? producto.precio.toString() : '',
    id_Categoria: producto.id_Categoria ? producto.id_Categoria.toString() : '',
    id_proveedor: producto.id_proveedor ? producto.id_proveedor.toString() : '',
    Cantidad_productos: producto.Cantidad_productos ? producto.Cantidad_productos.toString() : '',
  });
  const [categorias, setCategorias] = useState([]);
  const [proveedores, setProveedores] = useState([]);

  useEffect(() => {
    fetchCategorias();
    fetchProveedores();
  }, []);

  const fetchCategorias = async () => {
    try {
      const response = await axios.get(`${API_URL}/categorias`);
      setCategorias(response.data);
    } catch (error) {
      console.error('Error al obtener categorías:', error);
    }
  };
  
  const fetchProveedores = async () => {
    try {
      const response = await axios.get(`${API_URL}/proveedores`);
      setProveedores(response.data);
    } catch (error) {
      console.error('Error al obtener proveedores:', error);
    }
  };

  const handleChange = (campo, valor) => {
    setProductoEditado({
      ...productoEditado,
      [campo]: valor
    });
  };

  const handleEdit = async () => {
    try {
      await axios.put(`${API_URL}/productos/${producto.id_producto}`, productoEditado);
      Alert.alert('Éxito', 'Producto editado exitosamente');
      navigation.goBack();
    } catch (error) {
      console.error('Error al editar el producto:', error);
      Alert.alert('Error', 'Ocurrió un error al editar el producto. Inténtalo de nuevo.');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Editar Producto</Text>
      <Text style={styles.label}>Nombre del producto:</Text>
      <TextInput
        style={styles.input}
        placeholder="Nombre del producto"
        value={productoEditado.nombre_producto}
        onChangeText={(text) => setProductoEditado({ ...productoEditado, nombre_producto: text })}
      />
      <Text style={styles.label}>Precio:</Text>
      <TextInput
        style={styles.input}
        placeholder="Precio"
        value={productoEditado.precio}
        onChangeText={(text) => setProductoEditado({ ...productoEditado, precio: text })}
        keyboardType="numeric"
      />
      <View style={styles.pickerContainer}>
        <Text style={styles.label}>Categoría:</Text>
        <Picker
          style={styles.picker}
          selectedValue={productoEditado.id_Categoria}
          onValueChange={(itemValue) => handleChange('id_Categoria', itemValue)}
        >
          <Picker.Item label="Seleccionar categoría" value="" />
          {categorias.map(categoria => (
            <Picker.Item key={categoria.id_Categoria} label={categoria.Categorias} value={categoria.id_Categoria} />
          ))}
        </Picker>
      </View>
      <View style={styles.pickerContainer}>
        <Text style={styles.label}>Proveedor:</Text>
        <Picker
          style={styles.picker}
          selectedValue={productoEditado.id_proveedor}
          onValueChange={(itemValue) => handleChange('id_proveedor', itemValue)}
        >
          <Picker.Item label="Seleccionar proveedor" value="" />
          {proveedores.map(proveedor => (
            <Picker.Item key={proveedor.id_proveedor} label={proveedor.proveedores} value={proveedor.id_proveedor} />
          ))}
        </Picker>
      </View>
      <Text style={styles.label}>Cantidad:</Text>
      <TextInput
        style={styles.input}
        placeholder="Cantidad de productos"
        value={productoEditado.Cantidad_productos}
        onChangeText={(text) => setProductoEditado({ ...productoEditado, Cantidad_productos: text })}
        keyboardType="numeric"
      />
      <Button title="Guardar Cambios" onPress={handleEdit} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
    backgroundColor: '#6495ed'
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  input: {
    width: '100%',
    height: 40,
    backgroundColor: '#ffffff', 
    borderColor: '#000000', 
    borderWidth: 1,
    marginBottom: 10,
    paddingHorizontal: 10,
    borderRadius: 5,
  },
  pickerContainer: {
    width: '100%',
    marginBottom: 10,
  },
  label: {
    fontSize: 16,
    marginBottom: 5,
  },
  picker: {
    width: '100%',
    height: 40,
    borderColor: '#ccc',
    backgroundColor: '#ffffff', 
    borderWidth: 1,
    borderRadius: 5,
  },
});

export default EditarProducto;
