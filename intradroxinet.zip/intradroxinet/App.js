import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import ProductList from './ProductList';
import EditarProducto from './EditarProducto';
import AgregarProducto from './AgregarProducto'; // Asegúrate de importar AgregarProducto correctamente

const Stack = createStackNavigator();

const App = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="ProductList" component={ProductList} />
        <Stack.Screen name="AgregarProducto" component={AgregarProducto} />
        <Stack.Screen name="EditarProducto" component={EditarProducto} />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

export default App;

