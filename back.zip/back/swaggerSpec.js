const swaggerJSDoc = require('swagger-jsdoc');

// Define las opciones de configuración para swagger-jsdoc
const options = {
  // Define la información general de la API
  swaggerDefinition: {
    openapi: '3.0.0', // Especifica la versión de OpenAPI que estás utilizando
    info: {
      title: 'Documentación de la API INTRADROXINET', // Título de tu API
      version: '1.0.0', // Versión de tu API
      description: 'Documentación de la API creada con Swagger', // Descripción de tu API
    },
    servers: [
      {
        url: 'http://localhost:9300', // URL base de tu API
        description: 'Servidor local',
      },
    ],
  },
  // Especifica las rutas donde se encuentran tus especificaciones Swagger para cada endpoint de la API
  apis: ['./productos.js'], // Ruta de tu archivo principal donde tienes definidas las rutas de tu API
};

// Genera la especificación OpenAPI basada en las opciones de configuración
const swaggerSpec = swaggerJSDoc(options);

module.exports = swaggerSpec;
