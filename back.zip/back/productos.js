const express = require('express');
const mysql = require('mysql');
const bodyParser = require('body-parser');
const swaggerUi = require('swagger-ui-express');
const swaggerSpec = require('./swaggerSpec');

const app = express();

app.use(function(req, res, next) {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', '*');
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});

app.use(bodyParser.json());

const PUERTO = 9300;

const conexion = mysql.createConnection({
    host: 'localhost',
    port: 3306,
    database: 'intradroxinet',
    user: 'root',
    password: ''
});

app.listen(PUERTO, () => {
    console.log(`Servidor corriendo en el puerto ${PUERTO}`);
});

conexion.connect(error => {
    if (error) throw error;
    console.log('Conexión exitosa a la base de datos');
});

/**
 * @swagger
 * /:
 *   get:
 *     summary: Endpoint raíz de la API
 *     description: Retorna un mensaje indicando que la API está en funcionamiento.
 *     responses:
 *       '200':
 *         description: Mensaje de éxito
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 */
app.get('/', (req, res) => {
    res.send('API');
});

/**
 * @swagger
 * /productos:
 *   get:
 *     summary: Obtiene una lista de productos
 *     description: Retorna una lista de todos los productos disponibles.
 *     responses:
 *       '200':
 *         description: Éxito
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 type: object
 *                 properties:
 *                   id_producto:
 *                     type: integer
 *                   nombre_producto:
 *                     type: string
 *                   precio:
 *                     type: number
 *                   Cantidad_productos:
 *                     type: integer
 *                   categorias:
 *                     type: string
 *                   proveedores:
 *                     type: string
 */
app.get('/productos', (req, res) => {
    const query = `SELECT p.id_producto, p.nombre_producto, p.precio, p.Cantidad_productos, c.categorias, pr.proveedores
    FROM producto p
    INNER JOIN categorias c ON p.id_Categoria = c.id_Categoria
    INNER JOIN proveedor pr ON p.id_proveedor = pr.id_proveedor;`;

    conexion.query(query, (error, resultado) => {
        if (error) return console.error(error.message);

        if (resultado.length > 0) {
            res.json(resultado);
        } else {
            res.json(`No hay registros`);
        }
    });
});

/**
 * @swagger
 * /productos/{id}:
 *   get:
 *     summary: Obtiene un producto por su ID
 *     description: Retorna un producto basado en su ID.
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: ID del producto a obtener
 *         schema:
 *           type: integer
 *     responses:
 *       '200':
 *         description: Éxito
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 id_producto:
 *                   type: integer
 *                 nombre_producto:
 *                   type: string
 *                 precio:
 *                   type: number
 *                 Cantidad_productos:
 *                   type: integer
 *                 categorias:
 *                   type: string
 *                 proveedores:
 *                   type: string
 */
app.get('/productos/:id', (req, res) => {
    const { id } = req.params;

    const query = `SELECT * FROM producto WHERE Id_producto=${id};`;
    conexion.query(query, (error, resultado) => {
        if (error) return console.error(error.message);

        if (resultado.length > 0) {
            res.json(resultado);
        } else {
            res.json(`No hay registros`);
        }
    });
});

// Endpoint para agregar un producto
/**
 * @swagger
 * /productos:
 *   post:
 *     summary: Agrega un nuevo producto
 *     description: Agrega un nuevo producto a la base de datos.
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               nombre_producto:
 *                 type: string
 *               precio:
 *                 type: number
 *               id_Categoria:
 *                 type: integer
 *               id_proveedor:
 *                 type: integer
 *               Cantidad_productos:
 *                 type: integer
 *     responses:
 *       '200':
 *         description: Producto agregado con éxito
 */
app.post('/productos', (req, res) => {
    const { nombre_producto, precio, id_Categoria, id_proveedor, Cantidad_productos } = req.body;

    const query = 'INSERT INTO producto (nombre_producto, precio, id_Categoria, id_proveedor, Cantidad_productos) VALUES (?, ?, ?, ?, ?)';
    const values = [nombre_producto, precio, id_Categoria, id_proveedor, Cantidad_productos];

    conexion.query(query, values, (error, result) => {
        if (error) {
            console.error('Error al insertar el producto: ', error);
            return res.status(500).json('Ocurrió un error al insertar el producto');
        }

        console.log('Se insertó correctamente el producto');
        res.json('Se insertó correctamente el producto');
    });
});

// Endpoint para actualizar un producto
/**
 * @swagger
 * /productos/{id}:
 *   put:
 *     summary: Actualiza un producto existente
 *     description: Actualiza un producto existente en la base de datos.
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: ID del producto a actualizar
 *         schema:
 *           type: integer
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               nombre_producto:
 *                 type: string
 *               precio:
 *                 type: number
 *               id_Categoria:
 *                 type: integer
 *               id_proveedor:
 *                 type: integer
 *               Cantidad_productos:
 *                 type: integer
 *     responses:
 *       '200':
 *         description: Producto actualizado con éxito
 */
app.put('/productos/:id', (req, res) => {
    const id = req.params.id;
    const { nombre_producto, precio, id_Categoria, id_proveedor, Cantidad_productos } = req.body;

    const query = 'UPDATE producto SET nombre_producto=?, precio=?, id_Categoria=?, id_proveedor=?, Cantidad_productos=? WHERE Id_producto=?';
    const values = [nombre_producto, precio, id_Categoria, id_proveedor, Cantidad_productos, id];

    conexion.query(query, values, (error, results) => {
        if (error) {
            console.error(error.message);
            return res.status(500).json('Ocurrió un error al actualizar el producto');
        }
        console.log(`Se actualizó correctamente el producto con ID ${id}`);
        res.json('Se actualizó correctamente el producto');
    });
});

// Endpoint para eliminar un producto
/**
 * @swagger
 * /productos/{id}:
 *   delete:
 *     summary: Elimina un producto
 *     description: Elimina un producto de la base de datos basado en su ID.
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: ID del producto a eliminar
 *         schema:
 *           type: integer
 *     responses:
 *       '200':
 *         description: Producto eliminado con éxito
 */
app.delete('/productos/:id', (req, res) => {
    const id = req.params.id;

    const query = `DELETE FROM producto WHERE Id_producto=${id}`;
    conexion.query(query, (error) => {
        if (error) {
            console.error(error.message);
            return res.status(500).json('Ocurrió un error al eliminar el producto');
        }

        console.log(`Se eliminó correctamente el producto con ID ${id}`);
        res.json('Se eliminó correctamente el producto');
    });
});

/**
 * @swagger
 * /categorias:
 *   get:
 *     summary: Obtiene todas las categorías
 *     description: Retorna una lista de todas las categorías disponibles.
 *     responses:
 *       '200':
 *         description: Éxito
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 type: object
 *                 properties:
 *                   id_Categoria:
 *                     type: integer
 *                   categorias:
 *                     type: string
 */
app.get('/categorias', (req, res) => {
    const query = 'SELECT * FROM categorias';
    conexion.query(query, (error, resultado) => {
        if (error) {
            console.error(error.message);
            return res.status(500).json('Ocurrió un error al obtener las categorías');
        }
        res.json(resultado);
    });
});

/**
 * @swagger
 * /proveedores:
 *   get:
 *     summary: Obtiene todos los proveedores
 *     description: Retorna una lista de todos los proveedores disponibles.
 *     responses:
 *       '200':
 *         description: Éxito
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 type: object
 *                 properties:
 *                   id_proveedor:
 *                     type: integer
 *                   proveedores:
 *                     type: string
 */
app.get('/proveedores', (req, res) => {
    const query = 'SELECT * FROM proveedor';
    conexion.query(query, (error, resultado) => {
        if (error) {
            console.error(error.message);
            return res.status(500).json('Ocurrió un error al obtener los proveedores');
        }
        res.json(resultado);
    });
});

app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec));

module.exports = app;
